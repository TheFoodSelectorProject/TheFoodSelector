$(document).ready(function(){
	

	$("#playAgain").click(function(){
	$.getScript("clearList.js");

	});


	 $("#getInformation").click(function(){
    	
    	$("#information_modal").modal();
    	

  });



});