
$(document).ready(function(){
    var timer = 80;
    var repeatEvery = 400;
    var raffleStop_check = false;
    var chosenRestaurant;
    var raffleAnimation;
    
    // When clicked, animation begins
    $("#animation").click(function(){
		 

     if(box0Full && box1Full && box2Full && box3Full && box4Full && !raffleStop_check){

     raffleStop_check = true;
     raffleIsRunning = true;
     raffleAnimation = setInterval(function(){ 
      
       // Add "winner" class to the first box
       $("#raffle0").addClass("winner");

         setTimeout(function(){
          $("#raffle0").removeClass("winner");
          $("#raffle1").addClass("winner");

            setTimeout(function(){
             $("#raffle1").removeClass("winner");
             $("#raffle2").addClass("winner");

              setTimeout(function(){
               $("#raffle2").removeClass("winner");
               $("#raffle3").addClass("winner");

                setTimeout(function(){
                 $("#raffle3").removeClass("winner");
                 $("#raffle4").addClass("winner");

                  setTimeout(function(){
                   $("#raffle4").removeClass("winner");

                  }, timer);
                
                }, timer);
              
              }, timer);

           }, timer);
       
        }, timer);

      }, repeatEvery);//End Interval

    } else if(raffleAnimation){
     
         $("#error").text("Raffle is raffling");
        $("#errorMessage").modal(); 

      }else { 
          
           $("#error").text("All Raffle boxes must be full. Choose more restaurants.");
        $("#errorMessage").modal();
      }

  });//END animation click

    //Stops the raffle animation
    $("#stopRaffle").click(function(){

        // RNG chooses which of the 5 has been choosen
        var choosen = Math.floor((Math.random() * 5 ) +1);

        // If raffle animation has not started && the stop check is false
        if(!raffleAnimation){
            
           $("#error").text("The raffle has not started yet!?");
           $("#errorMessage").modal();    

        } else if(!raffleStop_check){

           $("#error").text("The raffle must be restarted.");
           $("#errorMessage").modal();    
          

      // If stop Check is true
      }else if(raffleStop_check){

        raffleStop_check = false;

        $("#raffle0").removeClass("winner");
        $("#raffle1").removeClass("winner");
        $("#raffle2").removeClass("winner");
        $("#raffle3").removeClass("winner");
        $("#raffle4").removeClass("winner");

        // Raffle is not longer running
        raffleIsRunning = false;

        clearInterval(raffleAnimation);
        //console.log("Raffle Finished");

        // console.log("Choosen restaurant is: "+chosen);

          if(choosen == 1){
            $("#raffle0").addClass("winner");
            chosenRestaurant = $("#raffle0").text();
            $("#winner_modal").modal();
            $("#results").html("Winner! "+chosenRestaurant);
            $("#results2").html(chosenRestaurant);
            console.log("Winner is "+chosenRestaurant);

           } else if (choosen == 2){
            $("#raffle1").addClass("winner");
            chosenRestaurant = $("#raffle1").text();
            $("#winner_modal").modal();
            $("#results").html("Winner! "+chosenRestaurant);
            $("#results2").html(chosenRestaurant);
            console.log("Winner is "+chosenRestaurant);

          } else if (choosen == 3){
            $("#raffle2").addClass("winner");
            chosenRestaurant = $("#raffle2").text();
            $("#winner_modal").modal();
            $("#results").html("Winner! "+chosenRestaurant);
            $("#results2").html(chosenRestaurant);
            console.log("Winner is "+chosenRestaurant);

          } else if (choosen == 4){
              $("#raffle3").addClass("winner");
              chosenRestaurant = $("#raffle3").text();
              $("#winner_modal").modal();
              $("#results").html("Winner! "+chosenRestaurant);
              $("#results2").html(chosenRestaurant);
              console.log("Winner is "+chosenRestaurant);

          } else if (choosen == 5){
              $("#raffle4").addClass("winner");
              chosenRestaurant = $("#raffle4").text();
              $("#winner_modal").modal();
              $("#results").html("Winner! "+chosenRestaurant);
              $("#results2").html(chosenRestaurant);
              console.log("Winner is "+chosenRestaurant);
          }
			
			 //This handles seeting chosenRestaurant and giving it to the database
            console.log("BEFORE POST "+chosenRestaurant);
			 $.post('information', {name: chosenRestaurant}).then(function(response){
            console.log("AFTER POST "+chosenRestaurant);
			      console.log(response);
				 //$scope.winnerName = response[0].name;
				 //$scope.winnerAddress = response[0].address;
			 //console.log(response[0].name);
			 $("#name").html(response[0].name);
			 $("#address").html(response[0].address);
       $("#phoneNumber").html(response[0].number0);
       $("#hours").html(response[0].hours);
			});
			
			
      }

    });//END StopRaffle click

 });//END document ready