$(document).ready(function(){

  $("#clear").click(function(){

    // If the raffle is currently running the user should not be able to clear
    if(raffleIsRunning){

        $("#error").text("Raffle is raffling");
        $("#errorMessage").modal();


    } else {
    // Reset the popular list back to defaults
    $("#popularList td").removeClass("selected");
    $("#myUL li").removeClass("selected");
    $("#popularList td").addClass("ListRegular");
    
    // set all the boxes to false....aka empty
    box0Full = false;
    box1Full = false;
    box2Full = false;
    box3Full = false;
    box4Full = false;

    // Reset the raffle boxes back to default stylings
    $("#raffle0").text("Give");
    $("#raffle0").removeClass("winner");
    $("#raffle0").addClass("raffleBoxes");

    $("#raffle1").text("Me");
    $("#raffle1").removeClass("winner");
    $("#raffle1").addClass("raffleBoxes");

    $("#raffle2").text("Some");
    $("#raffle2").removeClass("winner");
    $("#raffle2").addClass("raffleBoxes");

    $("#raffle3").text("Food");
    $("#raffle3").removeClass("winner");
    $("#raffle3").addClass("raffleBoxes");

    $("#raffle4").text("Now");
    $("#raffle4").removeClass("winner");
    $("#raffle4").addClass("raffleBoxes");
    
    }
    
  });

});