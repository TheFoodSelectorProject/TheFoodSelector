$(document).ready(function(){
    
     
        $("#popularList td, #myUL li").click(function(){


        var text = $(this).text();
        //console.log(text);


            if(!box0Full){

                $("#raffle0").text(text);
               // $(this).removeClass("ListRegular");
                //$(this).addClass("selected");
                box0Full = true;
                console.log(text);

            } else if (!box1Full){

                $("#raffle1").text(text);
               // $(this).removeClass("ListRegular");
               // $(this).addClass("selected");
                 box1Full = true;
                 console.log(text);

            } else if (!box2Full){

                // $(this).removeClass("ListRegular");
                // $(this).addClass("selected");
                 $("#raffle2").text(text);
                 box2Full = true;
                 console.log(text);

            } else if (!box3Full){

                // $(this).removeClass("ListRegular");
                 //$(this).addClass("selected");
                 $("#raffle3").text(text);
                 box3Full = true;
                 console.log(text);

            } else if (!box4Full){

                // $(this).removeClass("ListRegular");
                // $(this).addClass("selected");
                 $("#raffle4").text(text);
                 box4Full = true;
                 console.log(text);

            } else if(box0Full && box1Full && box2Full && box3Full && box4Full){
                
                $("#error").text("All Boxes are full");
                $("#errorMessage").modal();
               
        }

    });
});