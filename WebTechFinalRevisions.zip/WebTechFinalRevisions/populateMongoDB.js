var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/foodSelectorDB';

var insertDocument = function(db) {
   db.collection('restaurants').insert(  [
   		//First Five are popular list items-----
   		{
		name: 'Red Stag Grill',
		address: '11 Boston Way, Asheville, NC 28803',
		number0: '(828) 398-5600',
		hours: '6AM–10PM'
		},

		{
		name: 'Sunset Terrace',
		address: '290 Macon Ave, Asheville, NC 28804',
		number0: '(828) 252-2711',
		hours: '11AM - 3PM  ~  5PM - 10PM'
		},

		{
		name: 'Inn on Biltmore Estate',
		address: '1 Antler Hill Rd, Asheville, NC 28803',
		number0: '(828) 225-1600',
		hours: 'Hours: By Reservation'
		},

		{
		name: 'Biscuit Head',
		address: '733 Haywood Rd, Asheville, NC 28806',
		number0: '(828) 333-5145',
		hours: '7AM–2PM'
		},
		
		{
		name: 'White Duck Taco Shop',
		address: '12 Biltmore Ave, Asheville, NC 28803',
		number0: '828-232-9191',
		hours: '11:30AM - 9PM'
		},

		{
		name: 'Rockys Hot Chicken Shack',
		address: '1455 Patton Ave, Asheville, NC 28806',
		number0: '(828) 575-2260',
		hours: '11AM–9PM'
		},

		//-------------------------------------------------
		{
		name: 'Applebees',
		address: '115 Tunnel Road, Asheville, NC 28805 ',
		number0: '828-251-9194',
		address: '279 Smokey Park Hwy, Asheville, NC 28806 ',
		number1: '828-670-9101',
		hours: '11:00am - 12:00am'
		},

		{
		name: 'Asheville Pizza & Brewing Co- Pizza',
		address: '675 Merrimon Ave, Asheville, NC 28804',
		number0: '(828) 254-1281',
		hours: '11AM–12AM'
		},

		{
		name: 'Asian Wok Restaurant - Chinese',
		address: '328 New Leicester Hwy, Asheville, NC 28806',
		number0: '(828) 258-6969',
		hours: '10:30AM–9:30PM'
		},

		{
		name: 'Asiana Grand Buffet - Japanese & South Asian',
		address: '1968 Hendersonville Rd, Asheville, NC 28803',
		number0: '(828) 654-8879',
		hours: '11AM–12AM'
		},

		{
		name: 'Ay Caramba Mexican Grill & Bar - Mexican',
		address: '503 New Leicester Hwy, Asheville, NC 28806',
		number0: '(828) 575-2835',
		hours: '11AM–10PM'
		},

		{
		name: 'All Souls Pizza - Pizza',
		address: '175 Clingman Ave, Asheville, NC 28801',
		number0: '(828) 254-0169',
		hours: '11:30AM–10PM'
		}


		
		
	])
};

MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  insertDocument(db, function() {
      db.close();
  });
});