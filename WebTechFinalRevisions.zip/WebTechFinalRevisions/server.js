var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var MongoClient = require('mongodb').MongoClient;
var db = null;

app.use(bodyParser.urlencoded({extended: true}));


MongoClient.connect("mongodb://localhost:27017/foodSelectorDB", function(err, dbconn) {
	if(!err){
		console.log("We are connected to the database!");
		db = dbconn;
	}
});

app.use(express.static('public'));

app.post('/information',function(req, res, next) {
	console.log(req);
	
	db.collection('restaurants',function(err,restaurantCollection){
		console.log(req.body.name);
		
		restaurantCollection.find(req.body).toArray(function(err,restaurants){
			return res.json(restaurants);
		});
	});	
});



app.listen(3000, function() {
	console.log("Hello from port 3000");
});